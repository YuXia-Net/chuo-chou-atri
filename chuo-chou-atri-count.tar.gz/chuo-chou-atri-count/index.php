<?php
// 处理计数逻辑
$countFile = 'count.txt';

// 获取当前计数
function getTotalCount() {
    global $countFile;
    if (!file_exists($countFile)) {
        file_put_contents($countFile, '0');
        return 0;
    }
    return intval(file_get_contents($countFile));
}

// 如果是POST请求且要求增加计数
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['increment']) && $_POST['increment'] == 1) {
    $currentCount = getTotalCount() + 1;
    file_put_contents($countFile, $currentCount);
    echo $currentCount;
    exit;
}

// 如果是GET请求，输出HTML页面
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>戳戳萝卜子</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            font-family: Arial, sans-serif;
            background-color: transparent;
            overflow: hidden;
        }
        
        .container {
            text-align: center;
            width: 100%;
            max-width: 400px;
        }
        
        #carrot {
            width: 80%;
            max-width: 200px;
            cursor: pointer;
            margin-bottom: 20px;
        }
        
        .hint {
            font-size: 18px;
            margin-bottom: 10px;
            color: #333;
        }
        
        .counter {
            font-size: 16px;
            color: #666;
            margin-bottom: 10px;
        }
        
        .contributions {
            font-size: 14px;
            color: #888;
            margin-top: 10px;
        }
        
        .sound-toggle {
            display: inline-block;
            margin-left: 10px;
            cursor: pointer;
            color: #666;
            font-size: 14px;
        }
        
        /* 加载动画样式 */
        .loading-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            margin-bottom: 20px;
        }
        
        .loading-text {
            font-size: 16px;
            color: #666;
            margin-top: 10px;
        }
        
        .loading-spinner {
            width: 40px;
            height: 40px;
            border: 4px solid #f3f3f3;
            border-top: 4px solid #ff8c00;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .hidden {
            display: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- 加载状态 -->
        <div id="loadingState" class="loading-container">
            <div class="loading-spinner"></div>
            <div class="loading-text">萝卜子正在赶来....!</div>
        </div>
        <div id="content" class="hidden">
            <img id="carrot" src="1.gif" alt="萝卜子" loading="lazy">
            <div class="hint">点击戳戳萝卜子</div>
            <div class="counter"> 已累计击打: <span id="totalCount"><?php echo getTotalCount(); ?></span> - 最高连击: <span id="maxCombo">0</span>
            </div>
            <div class="contributions">
                你贡献了: <span id="userCount">0</span> 次
                <span id="soundToggle" class="sound-toggle">🔊 音效: 开</span>
            </div>
        </div>
    </div>
    <audio id="hitSound" src="a.mp3" preload="none"></audio>
    <script>
        // 初始化变量
        let totalCount = <?php echo getTotalCount(); ?>;
        let currentCombo = 0;
        let maxCombo = 0;
        let userCount = 0;
        let isAnimating = false;
        let soundEnabled = true;
        
        // 获取DOM元素
        const loadingState = document.getElementById('loadingState');
        const content = document.getElementById('content');
        const carrot = document.getElementById('carrot');
        const totalCountDisplay = document.getElementById('totalCount');
        const maxComboDisplay = document.getElementById('maxCombo');
        const userCountDisplay = document.getElementById('userCount');
        const soundToggle = document.getElementById('soundToggle');
        const hitSound = document.getElementById('hitSound');
        
        // 资源加载函数
        function loadResources() {
            // 预加载音频
            hitSound.load();
            
            // 预加载
            const img = new Image();
            img.src = '1.gif';
            img.onload = function() {
                const img2 = new Image();
                img2.src = '2.gif';
                img2.onload = function() {
                    // 所有资源加载完成后显示内容
                    setTimeout(() => {
                        loadingState.classList.add('hidden');
                        content.classList.remove('hidden');
                        initGame();
                    }, 500); 
                };
            };
        }
        
        // 初始化游戏
        function initGame() {
                       
            // 点击事件处理
            carrot.addEventListener('click', function() {
                if (!isAnimating) {
                    // 增加计数
                    totalCount++;
                    currentCombo++;
                    userCount++;
                    
                    // 更新最高连击
                    if (currentCombo > maxCombo) {
                        maxCombo = currentCombo;
                        maxComboDisplay.textContent = maxCombo;
                    }
                    
                    // 更新显示
                    totalCountDisplay.textContent = totalCount;
                    userCountDisplay.textContent = userCount;
                    
                    // 播放音效
                    if (soundEnabled) {
                        hitSound.currentTime = 0;
                        hitSound.play();
                    }
                    
                    // 播放动画
                    playAnimation();

                    // 发送计数到服务器
                    updateCount();
                }
            });
            
            // 音效开关
            soundToggle.addEventListener('click', function() {
                soundEnabled = !soundEnabled;
                soundToggle.textContent = soundEnabled ? '🔊 音效: 开' : '🔈 音效: 关';
            });
        }
        
        // 播放动画函数
        function playAnimation() {
            isAnimating = true;
            
            // 替换为动画GIF
            const originalSrc = carrot.src;
            carrot.src = originalSrc.replace('1.gif', '2.gif');
            
            
            setTimeout(function() {
                carrot.src = originalSrc;
                isAnimating = false;
                
                // 重置连击计数
                setTimeout(function() {
                    if (!isAnimating) {
                        currentCombo = 0;
                    }
                }, 3000);
            }, 1000); 
        }
        
        // 更新计数到服务器
        function updateCount() {
            const xhr = new XMLHttpRequest();
            xhr.open('POST', '', true); 
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.send('increment=1');
        }
        
        // 自适应iframe高度
        function resizeIframe() {
            if (window.parent !== window) {
                const height = document.body.scrollHeight;
                window.parent.postMessage({
                    type: 'resizeIframe',
                    height: height
                }, '*');
            }
        }
        
        // 初始调整和监听窗口变化
        window.addEventListener('load', function() {
            loadResources();
            resizeIframe();
        });
        window.addEventListener('resize', resizeIframe);
        //by:夏/夏的博客/xiau.net
    </script>
</body>
</html>
