<?php
require_once 'config.php';
require_once 'functions.php';

// 创建数据库目录
if (!file_exists(DB_DIR)) {
    mkdir(DB_DIR, 0755, true);
}

// 初始化数据库
try {
    $db = new SQLite3(DB_NAME);
    
    // 创建计数表
    $db->exec('CREATE TABLE IF NOT EXISTS counts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        total INTEGER DEFAULT 0
    )');
    
    // 创建用户表
    $db->exec('CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        cookie_id TEXT UNIQUE,
        ip TEXT,
        user_agent TEXT,
        count INTEGER DEFAULT 0,
        last_visit TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )');
    
    // 初始化总计数
    $db->exec('INSERT OR IGNORE INTO counts (id, total) VALUES (1, 0)');
    
    $db->close();
} catch (Exception $e) {
    error_log('Database setup failed: ' . $e->getMessage());
    die('Database initialization failed');
}
?>

