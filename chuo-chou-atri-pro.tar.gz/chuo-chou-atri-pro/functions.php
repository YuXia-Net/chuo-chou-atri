<?php
require_once 'config.php';

// 获取总计数
function getTotalCount() {
    try {
        $db = new SQLite3(DB_NAME);
        $result = $db->querySingle('SELECT total FROM counts WHERE id = 1');
        $db->close();
        return $result ? $result : 0;
    } catch (Exception $e) {
        error_log('Error getting total count: ' . $e->getMessage());
        return 0;
    }
}

// 增加计数
function incrementCount($cookieId) {
    try {
        $db = new SQLite3(DB_NAME);
        
        // 开始事务
        $db->exec('BEGIN TRANSACTION');
        
        // 更新总计数
        $db->exec('UPDATE counts SET total = total + 1 WHERE id = 1');
        
        // 获取用户IP和UA
        $ip = $_SERVER['REMOTE_ADDR'];
        $ua = $_SERVER['HTTP_USER_AGENT'];
        
        // 更新或插入用户数据
        $stmt = $db->prepare('INSERT INTO users (cookie_id, ip, user_agent, count, last_visit) 
                             VALUES (:cookie_id, :ip, :user_agent, 1, CURRENT_TIMESTAMP)
                             ON CONFLICT(cookie_id) DO UPDATE SET 
                             count = count + 1, last_visit = CURRENT_TIMESTAMP');
        $stmt->bindValue(':cookie_id', $cookieId, SQLITE3_TEXT);
        $stmt->bindValue(':ip', $ip, SQLITE3_TEXT);
        $stmt->bindValue(':user_agent', $ua, SQLITE3_TEXT);
        $stmt->execute();
        
        // 提交事务
        $db->exec('COMMIT');
        $db->close();
        
        return getTotalCount();
    } catch (Exception $e) {
        error_log('Error incrementing count: ' . $e->getMessage());
        $db->exec('ROLLBACK');
        return false;
    }
}

// 获取排行榜数据
function getLeaderboard() {
    try {
        $db = new SQLite3(DB_NAME);
        $result = $db->query('SELECT ip, user_agent, count FROM users ORDER BY count DESC LIMIT 10');
        
        $leaderboard = [];
        while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
            // 处理IP显示
            $ip = $row['ip'];
            if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
                // IPv4处理
                $ipParts = explode('.', $ip);
                if (count($ipParts) >= 4) {
                    $row['ip'] = $ipParts[0] . '.' . $ipParts[1] . '.*.*';
                }
            } elseif (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
                // IPv6处理 - 仅显示前8位
                $ipParts = explode(':', $ip);
                $shortenedIp = '';
                $count = 0;
                foreach ($ipParts as $part) {
                    if ($count >= 4) break; // 只取前4段(8个字符)
                    if (!empty($part)) {
                        $shortenedIp .= $part . ':';
                        $count++;
                    }
                }
                $shortenedIp = rtrim($shortenedIp, ':') . ':*:*:*:*';
                $row['ip'] = $shortenedIp;
            }
            
            // 简化UA显示
            $ua = $row['user_agent'];
            if (strpos($ua, 'Mobile') !== false) {
                $row['device'] = 'Mobile';
            } elseif (strpos($ua, 'Tablet') !== false) {
                $row['device'] = 'Tablet';
            } elseif (strpos($ua, 'Windows') !== false) {
                $row['device'] = 'Windows PC';
            } elseif (strpos($ua, 'Macintosh') !== false) {
                $row['device'] = 'Mac';
            } elseif (strpos($ua, 'Linux') !== false) {
                $row['device'] = 'Linux PC';
            } else {
                $row['device'] = 'Unknown';
            }
            
            unset($row['user_agent']);
            $leaderboard[] = $row;
        }
        
        $db->close();
        return $leaderboard;
    } catch (Exception $e) {
        error_log('Error getting leaderboard: ' . $e->getMessage());
        return [];
    }
}

// 获取用户贡献次数
function getUserCount($cookieId) {
    try {
        $db = new SQLite3(DB_NAME);
        $stmt = $db->prepare('SELECT count FROM users WHERE cookie_id = :cookie_id');
        $stmt->bindValue(':cookie_id', $cookieId, SQLITE3_TEXT);
        $result = $stmt->execute();
        $count = $result->fetchArray(SQLITE3_NUM);
        $db->close();
        return $count ? $count[0] : 0;
    } catch (Exception $e) {
        error_log('Error getting user count: ' . $e->getMessage());
        return 0;
    }
}
?>
