<?php
require_once 'config.php';
require_once 'functions.php';


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['increment'])) {

    if (!isset($_COOKIE['carrot_user'])) {
        $cookieId = md5(uniqid(rand(), true));
        setcookie('carrot_user', $cookieId, time() + (86400 * 30), "/"); 
    } else {
        $cookieId = $_COOKIE['carrot_user'];
    }
    
    $totalCount = incrementCount($cookieId);
    $userCount = getUserCount($cookieId);
    
    header('Content-Type: application/json');
    echo json_encode([
        'total' => $totalCount,
        'userCount' => $userCount
    ]);
    exit;
}

$totalCount = getTotalCount();

$userCount = 0;
if (isset($_COOKIE['carrot_user'])) {
    $userCount = getUserCount($_COOKIE['carrot_user']);
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>戳戳萝卜子</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            font-family: Arial, sans-serif;
            background-color: transparent;
            overflow: hidden;
        }
        
        .container {
            text-align: center;
            width: 100%;
            max-width: 400px;
        }
        
        #carrot {
            width: 80%;
            max-width: 200px;
            cursor: pointer;
            margin-bottom: 20px;
        }
        
        .hint {
            font-size: 18px;
            margin-bottom: 10px;
            color: #333;
        }
        
        .counter {
            font-size: 16px;
            color: #666;
            margin-bottom: 10px;
        }
        
        .contributions {
            font-size: 14px;
            color: #888;
            margin-top: 10px;
        }
        
        .sound-toggle, .leaderboard-btn {
            display: inline-block;
            margin-left: 10px;
            cursor: pointer;
            color: #666;
            font-size: 14px;
        }
        
        /* 加载动画样式 */
        .loading-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            margin-bottom: 20px;
        }
        
        .loading-text {
            font-size: 16px;
            color: #666;
            margin-top: 10px;
        }
        
        .loading-spinner {
            width: 40px;
            height: 40px;
            border: 4px solid #f3f3f3;
            border-top: 4px solid #ff8c00;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .hidden {
            display: none;
        }
        
        /* 排行榜样式 */
        #leaderboardModal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.7);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }
        
        .leaderboard-content {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            max-width: 80%;
            max-height: 80%;
            overflow-y: auto;
        }
        
        .leaderboard-title {
            font-size: 20px;
            margin-bottom: 15px;
            text-align: center;
        }
        
        .leaderboard-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .leaderboard-table th, .leaderboard-table td {
            padding: 8px 12px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }
        
        .leaderboard-table th {
            background-color: #f5f5f5;
        }
        
        .close-btn {
            float: right;
            cursor: pointer;
            font-size: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- 加载状态 -->
        <div id="loadingState" class="loading-container">
            <div class="loading-spinner"></div>
            <div class="loading-text">萝卜子正在赶来....!</div>
        </div>
        <div id="content" class="hidden">
            <img id="carrot" src="1.gif" alt="萝卜子" loading="lazy">
            <div class="hint">点击戳戳萝卜子</div>
            <div class="counter"> 已累计击打: <span id="totalCount"><?php echo $totalCount; ?></span> - 最高连击: <span id="maxCombo">0</span>
            </div>
            <div class="contributions">
                你贡献了: <span id="userCount"><?php echo $userCount; ?></span> 次
                <span id="soundToggle" class="sound-toggle">🔊 音效: 开</span>
                <span id="leaderboardBtn" class="leaderboard-btn">🏆 排行榜</span>
            </div>
        </div>
    </div>
    
    <!-- 排行榜模态框 -->
    <div id="leaderboardModal">
        <div class="leaderboard-content">
            <span class="close-btn">&times;</span>
            <div class="leaderboard-title">排行榜</div>
            <table class="leaderboard-table">
                <thead>
                    <tr>
                        <th>IP</th>
                        <th>设备</th>
                        <th>点击次数</th>
                    </tr>
                </thead>
                <tbody id="leaderboardBody">
                    <!-- 排行榜数据将通过JS动态加载 -->
                </tbody>
            </table>
        </div>
    </div>
    
    <audio id="hitSound" src="a.mp3" preload="none"></audio>
    <script>
        // 初始化变量
        let totalCount = <?php echo $totalCount; ?>;
        let currentCombo = 0;
        let maxCombo = 0;
        let userCount = <?php echo $userCount; ?>;
        let isAnimating = false;
        let soundEnabled = true;
        
        // 获取DOM元素
        const loadingState = document.getElementById('loadingState');
        const content = document.getElementById('content');
        const carrot = document.getElementById('carrot');
        const totalCountDisplay = document.getElementById('totalCount');
        const maxComboDisplay = document.getElementById('maxCombo');
        const userCountDisplay = document.getElementById('userCount');
        const soundToggle = document.getElementById('soundToggle');
        const hitSound = document.getElementById('hitSound');
        const leaderboardBtn = document.getElementById('leaderboardBtn');
        const leaderboardModal = document.getElementById('leaderboardModal');
        const leaderboardBody = document.getElementById('leaderboardBody');
        const closeBtn = document.querySelector('.close-btn');
        
        // 资源加载函数
        function loadResources() {
            // 预加载音频
            hitSound.load();
            
            // 预加载图片
            const img = new Image();
            img.src = '1.gif';
            img.onload = function() {
                const img2 = new Image();
                img2.src = '2.gif';
                img2.onload = function() {
                    // 所有资源加载完成后显示内容
                    setTimeout(() => {
                        loadingState.classList.add('hidden');
                        content.classList.remove('hidden');
                        initGame();
                    }, 500); 
                };
            };
        }
        
        // 初始化游戏
        function initGame() {
            // 点击事件处理
            carrot.addEventListener('click', function() {
                if (!isAnimating) {
                    // 增加本地计数
                    totalCount++;
                    currentCombo++;
                    
                    // 更新最高连击
                    if (currentCombo > maxCombo) {
                        maxCombo = currentCombo;
                        maxComboDisplay.textContent = maxCombo;
                    }
                    
                    // 更新显示
                    totalCountDisplay.textContent = totalCount;
                    
                    // 播放音效
                    if (soundEnabled) {
                        hitSound.currentTime = 0;
                        hitSound.play();
                    }
                    
                    // 播放动画
                    playAnimation();

                    // 发送计数到服务器
                    updateCount();
                }
            });
            
            // 音效开关
            soundToggle.addEventListener('click', function() {
                soundEnabled = !soundEnabled;
                soundToggle.textContent = soundEnabled ? '🔊 音效: 开' : '🔈 音效: 关';
            });
            
            // 排行榜按钮
            leaderboardBtn.addEventListener('click', showLeaderboard);
            
            // 关闭排行榜
            closeBtn.addEventListener('click', hideLeaderboard);
            leaderboardModal.addEventListener('click', function(e) {
                if (e.target === leaderboardModal) {
                    hideLeaderboard();
                }
            });
        }
        
        // 播放动画函数
        function playAnimation() {
            isAnimating = true;
            
            // 替换为动画GIF
            const originalSrc = carrot.src;
            carrot.src = originalSrc.replace('1.gif', '2.gif');
            
            setTimeout(function() {
                carrot.src = originalSrc;
                isAnimating = false;
                
                // 重置连击计数
                setTimeout(function() {
                    if (!isAnimating) {
                        currentCombo = 0;
                    }
                }, 3000);
            }, 1000); 
        }
        
        // 更新计数到服务器
        function updateCount() {
            fetch('', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'increment=1'
            })
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    console.error(data.error);
                } else {
                    totalCount = data.total;
                    userCount = data.userCount;
                    totalCountDisplay.textContent = totalCount;
                    userCountDisplay.textContent = userCount;
                }
            })
            .catch(error => console.error('Error:', error));
        }
        
        // 显示排行榜
        function showLeaderboard() {
            fetch('leaderboard.php')
                .then(response => response.json())
                .then(data => {
                    leaderboardBody.innerHTML = '';
                    data.forEach(row => {
                        const tr = document.createElement('tr');
                        tr.innerHTML = `
                            <td>${row.ip}</td>
                            <td>${row.device}</td>
                            <td>${row.count}</td>
                        `;
                        leaderboardBody.appendChild(tr);
                    });
                    leaderboardModal.style.display = 'flex';
                })
                .catch(error => console.error('Error:', error));
        }
        
        // 隐藏排行榜
        function hideLeaderboard() {
            leaderboardModal.style.display = 'none';
        }
        
        // 页面加载完成后初始化
        document.addEventListener('DOMContentLoaded', loadResources);
    </script>
</body>
</html>
