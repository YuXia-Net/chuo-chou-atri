<?php
// 数据库配置
define('DB_DIR', 'db');
define('DB_LOCK_FILE', 'sql.lock.xiau.net');

// 检查是否已存在数据库
if (file_exists(DB_LOCK_FILE)) {
    $dbHash = trim(file_get_contents(DB_LOCK_FILE));
    define('DB_NAME', DB_DIR . '/' . $dbHash . '.db');
} else {
    // 生成随机哈希作为数据库名
    $dbHash = md5(uniqid(rand(), true));
    file_put_contents(DB_LOCK_FILE, $dbHash);
    define('DB_NAME', DB_DIR . '/' . $dbHash . '.db');
    
    // 初始化数据库
    require_once 'setup.php';
}
?>

